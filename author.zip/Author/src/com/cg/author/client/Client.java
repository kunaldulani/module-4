package com.cg.author.client;

import java.util.List;
import java.util.Scanner;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.service.AuthorService;

public class Client 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		AuthorService authorService = new AuthorService();
		Author author = new Author();
		int choiceid, choice =0;
				
		do
		{
			System.out.println("Select an Operation from the following\n");
			System.out.println("1. Add Author\n2.Find Author\n3. Delete Author\n4.Display all Authors\n5.Exit");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1: System.out.println("Enter First Name");
					author.setFirstName(sc.next());
					System.out.println("Enter Middle Name");
					author.setMiddleName(sc.next());
					System.out.println("Enter Last Name");
					author.setLastName(sc.next());
					System.out.println("Enter Phone Number");
					author.setPhoneNo(sc.next());
					
				try {
					choiceid = authorService.addAuthor(author);
					System.out.println("Author Inserted with ID "+ choiceid);
					
				} catch (AuthorException e) {
					
					e.printStackTrace();
				}
				break;
			
			case 2: System.out.println("Enter Author ID to search");
					choiceid = sc.nextInt();
				try {
					author = authorService.findAuthor(choiceid);
					if (author==null)
					{
					System.out.println("Author not found");
					}
					else
					{
						System.out.println("Author Details are:\nAuthor Name: "+author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+"\nPhone No.: "+author.getPhoneNo());
					}
				} catch (AuthorException e) {
					
					e.printStackTrace();
				}
					break;
			case 3: System.out.println("Enter Author ID to Delete: ");
					choiceid = sc.nextInt();
				try {
					author = authorService.deleteAuthor(choiceid);
					if (author==null)
					{
					System.out.println("Author not found");
					}
					else
					{
						System.out.println("Author Deleted.\nAuthor Details are:\nAuthor Name: "+author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+"\nPhone No.: "+author.getPhoneNo());
					}
				} catch (AuthorException e1) {
					
					e1.printStackTrace();
				}
					break;
			
			case 4: try {
					List<Author> listAuth = authorService.displayAll();
							for(Object obj : listAuth)
							{
								Author auth = (Author) obj;
								System.out.println("Author ID: "+auth.getAuthorId()+"\nAuthor Name: "+auth.getFirstName()+" "+auth.getMiddleName()+" "+auth.getLastName()+"\nPhone No.: "+auth.getPhoneNo());
								
							}
				} catch (AuthorException e) {
					
					e.printStackTrace();
				}
					
			case 5: break;
			}
			
		}while(choice != 5);
	}
}
