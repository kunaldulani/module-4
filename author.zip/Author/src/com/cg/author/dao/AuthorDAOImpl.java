package com.cg.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.util.JPAUtil;

public class AuthorDAOImpl implements IAuthorDAO 
{
	private EntityManager entityManager = JPAUtil.getEntityManager();
	
	@Override
	public int addAuthor(Author author) throws AuthorException 
	{
		entityManager.persist(author);
		return author.getAuthorId();
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthorException {
		Author author = entityManager.find(Author.class, authorId);
		if(author == null)
		{
			return author;
			/*System.out.println("Author cannot be found.");*/
		}
		else
		{
			entityManager.remove(author);
			return author;
			/*System.out.println("Author was successfully deleted \n Details of deleted Author are as follows :\n Name :"+author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+"\nAuthor ID:"+author.getAuthorId()+"\nPhone Number : "+author.getPhoneNo());*/
		}
	}

	@Override
	public Author findAuthor(int authorId) throws AuthorException {
		Author author = entityManager.find(Author.class, authorId);
		return author;
	}


	@Override
	public List<Author> displayAll() throws AuthorException
	{
		TypedQuery<Author> query = entityManager.createNamedQuery("viewAllAuthor", Author.class);
		List<Author> list = query.getResultList();
		return list;
	}

}
