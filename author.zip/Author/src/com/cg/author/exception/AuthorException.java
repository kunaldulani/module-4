package com.cg.author.exception;

public class AuthorException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5315222056689408941L;

	public AuthorException(String message) 
	{
		super(message);
	}

	//
}
