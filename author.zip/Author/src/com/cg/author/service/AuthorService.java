package com.cg.author.service;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.author.dao.AuthorDAOImpl;
import com.cg.author.entities.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.util.JPAUtil;

public class AuthorService implements IAuthorService 
{
	AuthorDAOImpl authorDAO = new AuthorDAOImpl();
	EntityManager em = JPAUtil.getEntityManager();
	@Override
	public int addAuthor(Author author) throws AuthorException 
	{
		em.getTransaction().begin();
		int id = authorDAO.addAuthor(author);
		em.getTransaction().commit();
		return id;
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthorException 
	{
		em.getTransaction().begin();
		Author author = authorDAO.deleteAuthor(authorId);
		em.getTransaction().commit();
		return author;
	}

	@Override
	public Author findAuthor(int authorId) throws AuthorException 
	{
		em.getTransaction().begin();
		Author author = authorDAO.findAuthor(authorId);
		em.getTransaction().commit();
		return author;
	}

	@Override
	public List<Author> displayAll() throws AuthorException 
	{
		em.getTransaction().begin();
		List<Author> list = authorDAO.displayAll();
		em.getTransaction().commit();
		return list;
	}

}
